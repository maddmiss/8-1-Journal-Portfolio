/*
*Author: Suzanne Maddison
*Date: 10-20-2024
*/


#include <iostream>
#include <fstream>
#include <sstream>
#include <unordered_map>
#include <string>

/*Function to read the input file and populate map*/
void readInputFile(const std::string& filename, std::unordered_map<std::string, int>& frequencies) {
    std::ifstream file(filename);

    /*Check if file was opened successfully*/
    if (!file.is_open()) {
        std::cerr << "Could not open the file " << filename << std::endl;
        return;
    }

    std::string line;
    /*Read each line*/
    while (std::getline(file, line)) {
        std::istringstream iss(line);
        std::string item;
        /*Read each item and update frequency*/
        while (iss >> item) {
            frequencies[item]++;
        }
    }
    file.close(); /*close after reading*/
}

/*Function to display the frequency of all items*/
void displayFrequency(const std::unordered_map<std::string, int>& frequencies) {
    for (const auto& pair : frequencies) {
        std::cout << pair.first << ": " << pair.second << std::endl; /* Print item and its frequency*/
    }
}

/*Function to display a histogram of item frequencies*/
void displayHistogram(const std::unordered_map<std::string, int>& frequencies) {
    for (const auto& pair : frequencies) {
        std::cout << pair.first << " " << std::string(pair.second, '*') << std::endl; /*Print item followed by asterisks*/
    }
}

/*Function to save the frequency data to a backup file*/
void saveToFile(const std::unordered_map<std::string, int>& frequencies, const std::string& backupFilename) {
    std::ofstream file(backupFilename);
    /*Write each item and its frequency to the backup file*/
    for (const auto& pair : frequencies) {
        file << pair.first << ": " << pair.second << std::endl;
    }
    file.close(); /*Close the backup file*/
}

int main() {
    const std::string inputFilename = "CS210_Project_Three_Input_File.txt"; /*Input file*/
    const std::string backupFilename = "frequency.dat"; /*Back up file name*/
    std::unordered_map<std::string, int> frequencies; /*Map to store item freq*/

    /*Read input file*/
    readInputFile(inputFilename, frequencies);

    while (true) {
        /*Display menus*/
        std::cout << "\nMenu:\n";
        std::cout << "1. Check frequency of a specific item\n";
        std::cout << "2. Display frequency of all items\n";
        std::cout << "3. Display histogram of items\n";
        std::cout << "4. Exit\n";

        /*Handle user choice*/
        int choice;
        std::cout << "Enter your choice (1-4): ";
        std::cin >> choice; /*Get user choice*/

        if (choice == 1) {
            std::string item;
            std::cout << "Enter the item you wish to look for: ";
            std::cin >> item; /*Get specific choice*/
            std::cout << item << ": " << frequencies[item] << std::endl; /*Show item freq*/
        }
        else if (choice == 2) {
            displayFrequency(frequencies); /*Show all item freq*/
        }
        else if (choice == 3) {
            displayHistogram(frequencies); /*Show histogram of item freq*/
        }
        else if (choice == 4) {
            saveToFile(frequencies, backupFilename); /*Save freq to back up file*/
            std::cout << "Data saved to " << backupFilename << ". Exiting program." << std::endl;
            break; /*Exit loop and program*/
        }
        else {
            std::cout << "Invalid choice. Please try again." << std::endl; /*Handle invalid iput*/
        }
    }

    return 0; /*Successful completion*/
}



